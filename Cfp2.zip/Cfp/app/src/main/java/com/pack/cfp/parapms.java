package com.pack.cfp;

import java.util.ArrayList;
import java.util.HashMap;

public class parapms {
    public static ArrayList<HashMap<String,String>> values= new ArrayList<HashMap<String, String>>();
}
